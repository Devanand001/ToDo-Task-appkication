# todo-list-angular-django
to-do-list app powered by AngularJS, Django, and Angular-ui

modified from [Django tutorial 1.7](https://docs.djangoproject.com/en/1.7/intro/tutorial01/)


## Environment

* Ubuntu 14, x64
* Django 1.7 (Currently latest: 1.9)
* Angular 1.5.0

## Run

* `$ cp db.sqlite3.example db.sqlite3  # copy example db file`
* `$ python manage.py runserver http://localhost:8888`
